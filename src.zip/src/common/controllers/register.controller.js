"use strict";

angular.module('iDocApp')
    .controller('RegisterCtrl', function ($scope, IdocRestService, $uibModalInstance) {
    	$scope.close = function () {
    		$uibModalInstance.dismiss('cancel');
    	}
        
        $scope.register = function(user) {
        	var data = 'email='+ user.email + 'password=' + user.password;
        	IdocRestService.register(data).then(function (response) {
        		alert('aaaa');
        	});        	
        }
    });
